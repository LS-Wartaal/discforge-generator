package com.discforge.template.item;

import com.discforge.template.api.SongInfo;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

public class DiscItem extends Item {

    private final SongInfo song;

    public DiscItem(SongInfo song, Properties properties) {
        super(properties);
        this.song = song;
    }

    public SongInfo getSong() {
        return song;
    }

    @Override
    public void appendHoverText(
            ItemStack stack,
            TooltipContext context,
            List<Component> tooltip,
            TooltipFlag flag
    ) {

        tooltip.add(
                Component.translatable("album.dftemplate." + song.album())
                        .append(Component.literal(" • "))
                        .append(Component.translatable("artist.dftemplate." + song.artist()))
                        .withStyle(ChatFormatting.GRAY)
        );
    }
}