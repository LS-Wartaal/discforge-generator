package com.discforge.template.sound;

import com.discforge.template.DFTemplate;
import com.discforge.template.album.AlbumInfo;
import com.discforge.template.api.SongInfo;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModSounds {

    private ModSounds() {
    }

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, DFTemplate.MODID);

    public static final Map<String, DeferredHolder<SoundEvent, SoundEvent>> SOUNDS =
            new LinkedHashMap<>();

    static {

        for (SongInfo song : AlbumInfo.ALBUM.getSongs()) {

            DeferredHolder<SoundEvent, SoundEvent> sound =
                    SOUND_EVENTS.register(
                            song.id(),
                            () -> SoundEvent.createVariableRangeEvent(
                                    ResourceLocation.fromNamespaceAndPath(
                                            DFTemplate.MODID,
                                            song.id()
                                    )
                            )
                    );

            SOUNDS.put(song.id(), sound);
        }
    }
}