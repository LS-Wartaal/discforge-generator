package com.discforge.template.api;

public interface AlbumProvider {

    Album getAlbum();

}