package com.discforge.template.api;

public record SongInfo(

        String id,

        String title,

        String album,

        String artist,

        int lengthInSeconds,

        int comparatorOutput

) {
}