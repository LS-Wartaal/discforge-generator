package com.discforge.template.registry;

import com.discforge.template.api.SongInfo;
import com.discforge.template.item.DiscItem;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;

public record RegisteredSong(

        SongInfo song,

        DeferredItem<DiscItem> item,

        DeferredHolder<SoundEvent, SoundEvent> sound

) {
}