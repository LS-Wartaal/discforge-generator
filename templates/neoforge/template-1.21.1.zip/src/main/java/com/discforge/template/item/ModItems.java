package com.discforge.template.item;

import com.discforge.template.DFTemplate;
import com.discforge.template.album.AlbumInfo;
import com.discforge.template.api.SongInfo;
import com.discforge.template.jukebox.ModJukeboxSongs;
import com.discforge.template.registry.RegisteredSong;
import com.discforge.template.sound.ModSounds;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {

    private ModItems() {
    }

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(DFTemplate.MODID);

    public static final List<RegisteredSong> DISCS =
            new ArrayList<>();

    static {

        for (SongInfo song : AlbumInfo.ALBUM.getSongs()) {

            DeferredItem<DiscItem> item = ITEMS.register(

                    song.id() + "_disc",

                    () -> new DiscItem(
                            song,
                            new Item.Properties()
                                    .stacksTo(1)
                                    .jukeboxPlayable(
                                            ModJukeboxSongs.SONGS.get(song.id())
                                    )
                    )
            );

            DISCS.add(
                    new RegisteredSong(
                            song,
                            item,
                            ModSounds.SOUNDS.get(song.id())
                    )
            );
        }
    }
}