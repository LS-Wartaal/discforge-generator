package com.discforge.template.api;

import java.util.List;

public class Album {

    private final String modId;
    private final String id;
    private final String name;
    private final String artist;
    private final List<SongInfo> songs;

    public Album(
            String modId,
            String id,
            String name,
            String artist,
            List<SongInfo> songs
    ) {
        this.modId = modId;
        this.id = id;
        this.name = name;
        this.artist = artist;
        this.songs = songs;
    }

    public String getModId() {
        return modId;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getArtist() {
        return artist;
    }

    public List<SongInfo> getSongs() {
        return songs;
    }
}