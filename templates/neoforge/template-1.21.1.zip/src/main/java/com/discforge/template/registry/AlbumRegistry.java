package com.discforge.template.registry;

import com.discforge.template.album.AlbumInfo;

public final class AlbumRegistry {

    private AlbumRegistry() {
    }

    public static final String MOD_ID = AlbumInfo.ALBUM.getId();

    public static final String ALBUM_NAME = AlbumInfo.ALBUM.getName();

    public static final String ARTIST = AlbumInfo.ALBUM.getArtist();

}