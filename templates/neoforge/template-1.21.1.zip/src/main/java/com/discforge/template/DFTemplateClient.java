package com.discforge.template;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

@Mod(value = DFTemplate.MODID, dist = Dist.CLIENT)
public class DFTemplateClient {

    public DFTemplateClient(ModContainer container) {
    }
}