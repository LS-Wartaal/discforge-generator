package com.discforge.template;

import com.discforge.template.item.ModItems;
import com.discforge.template.registry.RegisteredSong;
import com.discforge.template.sound.ModSounds;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import com.discforge.template.album.AlbumInfo;

@Mod(DFTemplate.MODID)
public class DFTemplate {

    public static final String MODID = "dftemplate";

    public DFTemplate(IEventBus modEventBus, ModContainer modContainer) {

        ModItems.ITEMS.register(modEventBus);
        ModSounds.SOUND_EVENTS.register(modEventBus);

        modEventBus.addListener(this::buildCreativeTab);
    }

    private void buildCreativeTab(BuildCreativeModeTabContentsEvent event) {

        if (!event.getTabKey().equals(CreativeModeTabs.TOOLS_AND_UTILITIES))
            return;

        for (RegisteredSong song : ModItems.DISCS) {
            event.accept(song.item());
        }
    }
}