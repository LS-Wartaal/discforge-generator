package com.discforge.template.provider;

import com.discforge.template.api.Album;
import com.discforge.template.api.AlbumProvider;
import com.discforge.template.album.AlbumInfo;

public class GeneratedAlbumProvider implements AlbumProvider {

    @Override
    public Album getAlbum() {
        return AlbumInfo.ALBUM;
    }
}