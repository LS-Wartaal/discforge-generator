package com.discforge.template.jukebox;

import com.discforge.template.DFTemplate;
import com.discforge.template.album.AlbumInfo;
import com.discforge.template.api.SongInfo;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.JukeboxSong;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModJukeboxSongs {

    private ModJukeboxSongs() {
    }

    public static final Map<String, ResourceKey<JukeboxSong>> SONGS =
            new LinkedHashMap<>();

    static {
        for (SongInfo song : AlbumInfo.ALBUM.getSongs()) {
            SONGS.put(
                    song.id(),
                    ResourceKey.create(
                            Registries.JUKEBOX_SONG,
                            ResourceLocation.fromNamespaceAndPath(
                                    DFTemplate.MODID,
                                    song.id()
                            )
                    )
            );
        }
    }
}